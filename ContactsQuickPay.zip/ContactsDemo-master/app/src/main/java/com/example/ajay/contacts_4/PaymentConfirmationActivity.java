package com.example.ajay.contacts_4;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Rupy on 2/14/2018.
 */

public class PaymentConfirmationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.paymentconfirmation);


    }
}