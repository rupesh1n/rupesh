package com.example.ajay.contacts_4;

/**
 * Created by ajay on 27/9/15.
 */
public class Log {

    private static String TAG = "com.example.ajay.contacts_4";

    public static void I (String message){
        android.util.Log.i(TAG,message);
    }
}