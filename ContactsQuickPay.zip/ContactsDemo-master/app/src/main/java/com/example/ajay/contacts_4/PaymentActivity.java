package com.example.ajay.contacts_4;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

/**
 * Created by Rupy on 2/13/2018.
 */

public class PaymentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.payment);
    }

    public void onClick(View v) {
        Intent intent = new Intent(this, PaymentConfirmationActivity.class);
        startActivity(intent);

    }
}