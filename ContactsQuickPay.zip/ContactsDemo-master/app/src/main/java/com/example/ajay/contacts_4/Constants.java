package com.example.ajay.contacts_4;

/**
 * Created by ajay on 27/9/15.
 */
public class Constants {

    public static final String ACCOUNT_TYPE = "com.example.ajay.contacts_4";
    public static final String ACCOUNT_NAME = "Chase Mobile";
    public static final String ACCOUNT_TOKEN = "12345";

//    public static final String AUTHTOKEN_TYPE_READ_ONLY = "Read only";

    public static final String AUTHTOKEN_TYPE_FULL_ACCESS = "Full access";
}