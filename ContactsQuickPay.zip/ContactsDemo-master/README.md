# ContactsDemo
A sample application to demonstrate contacts syncing with android app.

NOTICE:-
It will not work with Android version 23 onwards since the run-time permissions were added. What you can do is use the code for referencing the approach.
